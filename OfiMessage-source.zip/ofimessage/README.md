# OfiMessage — Flutter starter

A premium dark-mode, local-first messaging app starter for Android and iOS.

## Included in this preview
- Flutter app shell with Chats / Nearby / Settings navigation
- Premium dark UI and sample conversation screen
- Bluetooth LE scan screen using `flutter_blue_plus`
- Basic local draft persistence using `shared_preferences`
- Permission request flow for Bluetooth scanning

## Not yet implemented (important)
This is a source-code starter, **not a finished WhatsApp replacement**:
- Bluetooth scan results are discovery only; there is no pairing or message transport.
- No mesh relay protocol, store-and-forward routing, or offline voice calling yet.
- No production end-to-end encryption protocol or verified key exchange.
- No WhatsApp message integration. WhatsApp does not expose unrestricted access to private chats.
- No contacts import, file transfer, push notifications, desktop sync, or encrypted cloud backup.
- The current chat screen is a local UI preview; messages are not sent to another device.

Do not use this preview for sensitive communications. Production E2EE needs a reviewed protocol (for example, a correctly implemented Signal-style protocol), audited key storage, authenticated device pairing, replay protection, and independent security review.

## Requirements
- Flutter stable (Dart 3.3+)
- Android Studio / Android SDK for Android builds
- macOS with Xcode for iOS builds and signing

## Run
```bash
flutter pub get
flutter run
```

## Build
Android APK:
```bash
flutter build apk --release
```

iOS:
```bash
flutter build ipa --release
```
The iOS build must be performed on macOS with Xcode and an Apple Developer signing setup. This archive does not include signed APK or IPA binaries.

## Recommended next engineering milestones
1. Define the offline transport: BLE for discovery/control plus Wi-Fi Direct / local network where available for larger payloads.
2. Implement authenticated pairing and a reviewed E2EE protocol before sending real messages.
3. Add durable encrypted message queue and mesh store-and-forward with TTL, deduplication and delivery receipts.
4. Add Android foreground service and iOS-compatible background strategy (iOS background BLE is constrained).
5. Add voice calling only between compatible installed devices with a real transport; calls cannot reach non-app users without telecom infrastructure.
6. Add encrypted export/restore, contacts permission flow, file transfer, push and desktop clients.

## Platform notes
Android and iOS impose different Bluetooth/background execution rules. iOS apps cannot freely run an always-on generic mesh relay in the background. Reliable cross-platform offline mesh behavior needs careful platform-specific engineering and real-device testing.


## Build APK through GitHub Actions (no local Flutter installation)
1. Create a GitHub repository and upload this project.
2. Open the repository's **Actions** tab.
3. Select **Build OfiMessage Android APK** and choose **Run workflow**.
4. When the run succeeds, open that workflow run and download the `OfiMessage-Android-APK` artifact.
5. The artifact contains `app-release.apk`.

This workflow builds an APK in GitHub's hosted Android build environment. It does not publish a public website or Play Store listing automatically. For a public download page, publish a GitHub Release and attach the APK after reviewing and signing it with your own release key.
