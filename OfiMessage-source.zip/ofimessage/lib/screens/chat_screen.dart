import 'package:flutter/material.dart';
import '../services/local_store.dart';

class ChatScreen extends StatefulWidget {
  final String name;
  const ChatScreen({super.key, required this.name});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final store = LocalStore();
  final messages = <String>['This is your private space.', 'Messages are currently stored locally on this device.'];

  void send() {
    final value = controller.text.trim();
    if (value.isEmpty) return;
    setState(() => messages.add(value));
    controller.clear();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Row(children: [
      const CircleAvatar(backgroundColor: Color(0xFF263653), child: Icon(Icons.person, color: Color(0xFFBBD0FF))),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const Text('Local preview chat', style: TextStyle(fontSize: 11, color: Colors.white54)),
      ]),
    ])),
    body: Column(children: [
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.all(16), itemCount: messages.length,
        itemBuilder: (_, i) => Align(
          alignment: i < 2 ? Alignment.centerLeft : Alignment.centerRight,
          child: Container(
            margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
            constraints: const BoxConstraints(maxWidth: 290),
            decoration: BoxDecoration(
              color: i < 2 ? const Color(0xFF171D29) : const Color(0xFF315DAA),
              borderRadius: BorderRadius.circular(17),
            ),
            child: Text(messages[i]),
          ),
        ),
      )),
      SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(children: [
          IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('File transfer will be added with the secure transport layer.'))), icon: const Icon(Icons.add_circle_outline)),
          Expanded(child: TextField(controller: controller, onSubmitted: (_) => send(), decoration: InputDecoration(
            hintText: 'Message', filled: true, fillColor: const Color(0xFF171D29),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          ))),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: send, icon: const Icon(Icons.arrow_upward_rounded)),
        ]),
      )),
    ]),
  );
}
