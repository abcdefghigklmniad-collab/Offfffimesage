import 'package:flutter/material.dart';
import '../services/local_store.dart';
import 'chat_screen.dart';
import 'nearby_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final store = LocalStore();
  final chats = const [
    ChatPreview('Mia', 'Are we still meeting later?', '16:08', true, 'M'),
    ChatPreview('Alex', 'That file came through 👍', '15:42', false, 'A'),
    ChatPreview('Weekend crew', 'Sam: On my way', '14:19', false, 'W'),
    ChatPreview('Jordan', 'Voice message · 0:18', 'Yesterday', false, 'J'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 20,
        title: const Row(children: [
          Icon(Icons.bolt_rounded, color: Color(0xFF78A1FF), size: 27),
          SizedBox(width: 8),
          Text('OfiMessage', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.5)),
        ]),
        actions: [
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NearbyScreen())),
            icon: const Icon(Icons.bluetooth_searching_rounded), tooltip: 'Nearby devices'),
          IconButton(onPressed: () => _showInfo(context), icon: const Icon(Icons.more_vert)),
          const SizedBox(width: 8),
        ],
      ),
      body: IndexedStack(index: tab, children: [
        _chatList(),
        const NearbyScreen(),
        _settings(),
      ]),
      floatingActionButton: tab == 0 ? FloatingActionButton(
        onPressed: () => _newChat(context),
        backgroundColor: const Color(0xFF5B8CFF),
        foregroundColor: Colors.white,
        child: const Icon(Icons.edit_rounded),
      ) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.radar_rounded), label: 'Nearby'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _chatList() => ListView(
    padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
    children: [
      const Text('Stay connected.', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      Text('Private messages. Even when the internet isn’t there.', style: TextStyle(color: Colors.white.withOpacity(.58))),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF1C3159), Color(0xFF172033)]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFF456CB4).withOpacity(.35)),
        ),
        child: const Row(children: [
          Icon(Icons.bluetooth_connected_rounded, color: Color(0xFF8DB1FF), size: 25),
          SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Offline mode ready', style: TextStyle(fontWeight: FontWeight.w700)),
            SizedBox(height: 3),
            Text('Open Nearby to discover compatible devices.', style: TextStyle(fontSize: 12, color: Color(0xFFB7C8E8))),
          ])),
          Icon(Icons.chevron_right, color: Color(0xFFB7C8E8)),
        ]),
      ),
      const SizedBox(height: 23),
      const Text('RECENT', style: TextStyle(fontSize: 11, letterSpacing: 1.5, color: Colors.white54, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...chats.map((c) => ListTile(
        contentPadding: const EdgeInsets.symmetric(vertical: 5, horizontal: 2),
        leading: CircleAvatar(radius: 25, backgroundColor: const Color(0xFF263653),
          child: Text(c.initial, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFBBD0FF)))),
        title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(c.message, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60)),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(c.time, style: const TextStyle(fontSize: 11, color: Colors.white54)),
          if (c.unread) const Padding(padding: EdgeInsets.only(top: 6), child: CircleAvatar(radius: 4, backgroundColor: Color(0xFF70A0FF))),
        ]),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(name: c.name))),
      )),
    ],
  );

  Widget _settings() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Settings', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
    const SizedBox(height: 18),
    _settingTile(Icons.lock_outline, 'Privacy & security', 'Encryption and device safety'),
    _settingTile(Icons.palette_outlined, 'Appearance', 'Premium dark theme'),
    _settingTile(Icons.contacts_outlined, 'Contacts', 'Contact access is opt-in'),
    _settingTile(Icons.backup_outlined, 'Encrypted backup', 'Backup setup is not yet connected'),
    _settingTile(Icons.devices_outlined, 'Linked devices', 'Desktop sync coming next'),
    const SizedBox(height: 20),
    Text('OfiMessage 0.1.0 · Preview build', style: TextStyle(color: Colors.white.withOpacity(.4), fontSize: 12)),
  ]);

  Widget _settingTile(IconData icon, String title, String subtitle) => Card(
    child: ListTile(leading: Icon(icon, color: const Color(0xFF8DB1FF)), title: Text(title), subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54))),
  );

  void _newChat(BuildContext context) {
    final controller = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Start a chat'),
      content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'Contact or device name')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          final name = controller.text.trim();
          Navigator.pop(context);
          if (name.isNotEmpty) Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(name: name)));
        }, child: const Text('Continue')),
      ],
    ));
  }

  void _showInfo(BuildContext context) => showAboutDialog(
    context: context, applicationName: 'OfiMessage',
    applicationVersion: '0.1.0 preview',
    children: const [Text('A local-first messaging app concept. Offline delivery requires compatible nearby devices and an implemented transport connection.')],
  );
}

class ChatPreview {
  final String name, message, time, initial;
  final bool unread;
  const ChatPreview(this.name, this.message, this.time, this.unread, this.initial);
}
