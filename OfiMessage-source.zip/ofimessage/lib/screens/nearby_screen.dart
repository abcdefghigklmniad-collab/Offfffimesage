import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class NearbyScreen extends StatefulWidget {
  const NearbyScreen({super.key});
  @override
  State<NearbyScreen> createState() => _NearbyScreenState();
}

class _NearbyScreenState extends State<NearbyScreen> {
  bool scanning = false;
  String status = 'Discover compatible nearby devices';
  final devices = <BluetoothDevice>[];

  Future<void> scan() async {
    setState(() { scanning = true; devices.clear(); status = 'Checking Bluetooth permissions…'; });
    try {
      await [Permission.bluetoothScan, Permission.bluetoothConnect, Permission.locationWhenInUse].request();
      if (await FlutterBluePlus.isSupported == false) {
        setState(() { status = 'Bluetooth LE is not supported on this device.'; scanning = false; });
        return;
      }
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 8));
      FlutterBluePlus.scanResults.listen((results) {
        if (!mounted) return;
        setState(() {
          for (final r in results) {
            if (!devices.any((d) => d.remoteId == r.device.remoteId)) devices.add(r.device);
          }
        });
      });
      await Future.delayed(const Duration(seconds: 8));
      await FlutterBluePlus.stopScan();
      if (mounted) setState(() { scanning = false; status = devices.isEmpty ? 'No nearby Bluetooth devices found.' : 'Nearby devices found'; });
    } catch (e) {
      if (mounted) setState(() { scanning = false; status = 'Bluetooth scan unavailable. Check permissions and device settings.'; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nearby devices')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22), color: const Color(0xFF141D2D),
      ), child: Column(children: [
        const Icon(Icons.radar_rounded, size: 55, color: Color(0xFF8DB1FF)),
        const SizedBox(height: 12),
        const Text('Find your people nearby', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(status, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60)),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: scanning ? null : scan, icon: Icon(scanning ? Icons.hourglass_top : Icons.bluetooth_searching), label: Text(scanning ? 'Scanning…' : 'Scan for devices')),
      ])),
      const SizedBox(height: 24),
      const Text('DISCOVERED DEVICES', style: TextStyle(fontSize: 11, letterSpacing: 1.4, color: Colors.white54, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Expanded(child: devices.isEmpty ? const Center(child: Text('Devices will appear here after a scan.', style: TextStyle(color: Colors.white38))) :
        ListView(children: devices.map((d) => Card(child: ListTile(leading: const Icon(Icons.bluetooth, color: Color(0xFF8DB1FF)), title: Text(d.platformName.isEmpty ? 'Unknown device' : d.platformName), subtitle: Text(d.remoteId.str), trailing: const Icon(Icons.chevron_right)))).toList())),
      const Text('Preview limitation: this screen discovers Bluetooth devices only. Secure pairing, message transport, relay routing and voice calling are not implemented yet.', style: TextStyle(color: Colors.white38, fontSize: 11)),
    ])),
  );
}
