import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OfiMessageApp());
}

class OfiMessageApp extends StatelessWidget {
  const OfiMessageApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF5B8CFF);
    return MaterialApp(
      title: 'OfiMessage',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
          surface: const Color(0xFF10131B),
        ),
        scaffoldBackgroundColor: const Color(0xFF090B10),
        useMaterial3: true,
        cardTheme: CardTheme(
          color: const Color(0xFF141925),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
