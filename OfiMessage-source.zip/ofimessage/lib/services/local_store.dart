import 'package:shared_preferences/shared_preferences.dart';

/// Minimal local key/value persistence helper. Do not store plaintext secrets here.
class LocalStore {
  Future<void> saveDraft(String conversationId, String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('draft:$conversationId', value);
  }

  Future<String> loadDraft(String conversationId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('draft:$conversationId') ?? '';
  }
}
